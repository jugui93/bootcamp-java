//1. Nací en 1980
//2. Nací en 1980
/*3. ¡Sumando números!
num1 is 10
num2 is 20
30 */