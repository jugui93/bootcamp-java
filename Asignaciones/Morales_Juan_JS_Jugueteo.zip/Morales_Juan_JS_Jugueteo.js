let alturaNino = 130;

function muestraSiElNinoPuedeSubirALaMontanaRusa(altura) {
    if (altura > 52) {
        console.log('¡Súbete, chico!')
    } else {
        console.log('Lo siento, chico. Tal vez el próximo año')
    }
}

muestraSiElNinoPuedeSubirALaMontanaRusa(alturaNino)