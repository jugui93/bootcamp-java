import java.util.ArrayList;

public class Pedido {
    String nombre;
    double total;
    boolean listo;
    ArrayList<Articulo> articulos = new ArrayList<>();
}