public class Test {
    public static void main(String[] args) {
        System.out.println("Mi nombre es Juan Morales");
        System.out.println("Tengo 28 años de edad");
        System.out.println("Mi ciudad natal es Bello-Colombia");
    }
}